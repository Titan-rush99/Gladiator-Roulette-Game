import java.util.Random;
import java.util.Scanner;

public class Skill extends ItemPool
{
    private int xp;
    private int sp;

    public Skill()
    {
        super();
        xp = 0;
        sp = 0;
    }

    //setter and getter methods to edit or return the states in Skill
    public void setXp(int xp){this.xp = xp;}
    public void setSp(int sp){this.sp = sp;}
    public int getXp(){return xp;}
    public int getSp(){return sp;}

    //Overrides the method in ItemPool, the method, based on the rarity of item created by createItem method in the
    //superclass, will call the assignStats method
    public void createItem()
    {
        int chance = getRandomInt(100) +1; //Chance for which skill to be selected
        super.createItem();
        if(getRarity().equals("Common")) //No common skill item
        {
            setCheckItemFound(false);
        }
        else if(getRarity().equals("Uncommon"))
        {
            assignStats(chance, 20);
        }
        else if(getRarity().equals("Rare"))
        {
            assignStats(chance, 30);
        }
    }

    //Method use chance to select which skill to bestow and assigns it a power
    public void assignStats(int chance, int power)
    {
        if(chance<=50)
        {
            setName("Robber's greed");
            setXp(power);
        }
        else
        {
            setName("Vital strike");
            setSp(power);
        }
    }

    //Method overrides miniGame method in SuperClass ItemPool, player selects an option and if it is the same as the
    //randomly selected option then enter if statement. Successfully doing this 3 times will allow player to obtain
    //skill to skip a round
    public int miniGame()
    {
        Random r = new Random();
        int randInt = r.nextInt(2) + 1; //randomly select an option
        System.out.println("You have found a power up crystal");
        Scanner scanner = new Scanner(System.in);
        System.out.println("(1)to CRACK (2) to POLISH");
        int answer = Integer.parseInt(scanner.nextLine());
        if((randInt == answer)) //chosen option same as the randomly selected option
        {
            randInt = r.nextInt(2) + 1;
            System.out.println("(1) to CRACK (2) to POLISH again");
            answer = Integer.parseInt(scanner.nextLine());
            if(randInt == answer)
            {
                randInt = r.nextInt(2) + 1;
                System.out.println("(1) to CRACK (2) to POLISH again");
                answer = Integer.parseInt(scanner.nextLine());
                if(randInt == answer)
                {
                    System.out.println("You have gained secret skill: Evasion");
                    System.out.println("Skill allows you to evade a champion and move onto the next round.");
                    return -1;
                }
            }
        }
        System.out.println("You were too weak to harness the crystal\n");
        return super.miniGame(); // return 0
    }

    //Method overrides the getItemStatus method in SuperClass ItemPool by adding further details about the skill
    public void getItemStats()
    {
        if(checkItemFound())
        {
            if(getItemName().equals("Robber's greed"))
            {
                System.out.println("You have obtained a skill.");
                System.out.println("Skill: " + getRarity() + getItemName());
                System.out.println("Skill description: Skill allows you to gain " + getXp()  + "xp while mining." );
                System.out.println("Skill has been equipped.\n");
            }
            else
            {
                System.out.println("You have obtained aa skill.");
                System.out.println("Skill: " + getRarity() + getItemName());
                System.out.println("Skill description: Deal critical damage of " + getSp() + "dmg when you attack an opponent's vital areas.");
                System.out.println("Skill has been equipped.\n");
            }
        }
        else
        {
            System.out.println("Hidden item");
        }
    }
}
