import java.util.Random;
public abstract class ItemPool
{
    private String name;
    private String rarity;
    private boolean checkItemFound;

    public ItemPool()
    {
        name = "";
        rarity = "";
        checkItemFound = false;
    }

    public static int getRandomInt(int range)
    {
        Random random = new Random();
        return random.nextInt(range);
    }

    //Method randomly assigns rarity to items, if a rarity was assigned then sets the checkItem variable to true
    public void createItem()
    {
        int chance = getRandomInt(100) + 1;
        if(chance>=1 && chance<=45)
        {
            rarity = "Common";
            checkItemFound = true;
        }
        else if(chance>=46 && chance<=75)
        {
            rarity = "Uncommon";
            checkItemFound = true;

        }
        else if(chance>=76 && chance<=95)
        {
            rarity = "Rare";
            checkItemFound = true;
        }
        else
        {
            checkItemFound = false;
        }
    }

    //Setter, change and getter methods to edit or return the states in ItemPool
    public void setName(String n){name = n;}
    public void setCheckItemFound(boolean b){checkItemFound = b;}
    public String getItemName(){return name;}
    public String getRarity(){return rarity;}
    public boolean checkItemFound(){return checkItemFound;}
    public abstract void getItemStats();
    public int miniGame(){return 0;}
}