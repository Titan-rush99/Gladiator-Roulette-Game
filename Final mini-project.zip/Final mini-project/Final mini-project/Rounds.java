public class Rounds
{
    private final int number_of_rounds;
    private int roundsSoFar;

    public Rounds(int max, int index)
    {
        number_of_rounds = max;
        roundsSoFar = index;
    }

    //change and getter methods to edit the instances in Rounds
    public void incrementRoundsSoFar(){roundsSoFar++;}
    public int getRoundsSoFar(){ return roundsSoFar;}
    public int getNumber_of_rounds(){ return number_of_rounds;}
}
