public abstract class Character
{
    private String name;
    private int hp; // health
    private int sp; // strength

    public Character(String name, int hp, int sp)
    {
        this.name = name;
        this.hp = hp;
        this.sp = sp;
    }

    //Setter methods to set new hp and sp, or change them by specified amount
    public void changeHp(int newHp){hp += newHp;}
    public void changeSp(int newSp){sp += newSp;}

    //Getter methods to return character name, hp or sp
    public String getName(){return name;}
    public int getHp(){return hp;}
    public int getSp(){return sp;}

    //Method where two characters fight. Each character takes turn to attack
    //the other with player going first and the hp of each character is
    //reduced by the other players strength each time
    public boolean battleCharacter(Character c)
    {
        int opponentHP = c.getHp();
        int opponentSP = c.getSp();
        int playerHP = hp;
        int playerSP = sp;
        boolean playerDead = false;

        while((playerHP >0) && (opponentHP > 0))
        {
            opponentHP -= playerSP;
            if(checkDead(opponentHP)) break;
            else {
                playerHP -= opponentSP;
                if(checkDead(playerHP)){
                    playerDead = true;
                    break;
                }
            }
        }
        return !playerDead; //return true if player is not dead, returns false if player is dead
    }

    //Method returns true if health of character is zero or below ie. dead
    public boolean checkDead(int hp)
    {
        return hp <= 0;
    }

    //This method displays details about the characters name, hp and sp
    public void getStats()
    {
        System.out.println("Name: " + name);
        System.out.println("Health: " + getHp());
        System.out.println("Strength: " + getSp());
    }
}