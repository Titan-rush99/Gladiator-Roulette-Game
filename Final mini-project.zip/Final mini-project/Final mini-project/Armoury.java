public class Armoury extends ItemPool
{
    private int hp;
    private int sp;

    public Armoury()
    {
        super();
        hp = 0;
        sp = 0;
    }

    //setter and getter methods to edit or return the states in Armoury
    public void setHp(int hp){this.hp = hp;}
    public void setSp(int sp){this.sp = sp;}
    public int getHp(){return hp;}
    public int getSp(){return sp;}

    //Overrides the method in ItemPool, the method, based on the rarity of item created by createItem method in the
    //superclass, will call the assignStats method
    public void createItem()
    {
        int chance = getRandomInt(100) +1;
        super.createItem();
        if(getRarity().equals("Common"))
        {
            assignStats(chance, 10);
        }
        else if(getRarity().equals("Uncommon"))
        {
            assignStats(chance, 20);
        }
        else if(getRarity().equals("Rare"))
        {
            assignStats(chance, 30);
        }
    }

    //Method use chance to select which armour/sword to bestow and assigns it a power
    public void assignStats(int chance, int power)
    {
        if(chance<=50)
        {
            setName("Sword");
            setSp(power);
        }
        else
        {
            setName("Armour");
            setHp(power);
        }
    }

    //Method overrides the getItemStatus method in SuperClass ItemPool by adding further details about the armour/sword
    public void getItemStats()
    {
        if(checkItemFound())
        {
            System.out.println("You have obtained an item.");
            System.out.println("Item: " + getRarity() + " " + getItemName());
            System.out.println("Item hp: " + getHp() + "\tItem sp: " + getSp());
            System.out.println("Item has been equipped.\n");
        }
        else
        {
            System.out.println("You have not found anything.\n");
        }
    }
}
