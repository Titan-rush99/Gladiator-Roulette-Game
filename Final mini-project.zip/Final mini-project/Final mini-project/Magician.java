public class Magician extends Opponents
{
    private int xp;

    public Magician(String name, int hp, int sp, int xp)
    {
        super(name, hp, sp);
        this.xp = xp;
    }

    public int getXp(){return xp;}

    //Method overrides the battleCharacter in the SuperClass Character, player can beat the magician if they have a
    //skill and have more xp than the magician
    public boolean battleCharacter(Character c)
    {
        Player p = (Player)c;
        int playerXP = p.getXP();
        super.assignItemSkill();
        ItemPool item = getItem(); //returns the drop item

        if(p.getSkill() && (playerXP > xp))
        {
            System.out.println("You have won the battle, skill unlocked");
            item.getItemStats();
            ((Player)c).setSkill(true);
            return true;
        }
        else if(playerXP < xp)
        {
            System.out.println("You don't have the wisdom of what it takes to beat the Magician");
            p.changeXP(-20);
            return false;
        }
        else
        {
            System.out.println("You don't have the skills of what it takes to beat the Magician");
            return false;
        }
    }

    //Method displays additional details about the xp in class Magician
    public void getStats()
    {
        super.getStats();
        System.out.println("XP: " + getXp());
    }
}
