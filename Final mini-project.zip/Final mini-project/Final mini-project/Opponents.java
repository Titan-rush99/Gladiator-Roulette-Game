import java.util.Random;

public class Opponents extends Character
{
    private ItemPool item;

    public Opponents(String name, int hp, int sp)
    {
        super(name, hp, sp);
    }

    public ItemPool getItem(){return item;}

    //Method overrides the battleCharacter in the SuperClass Character, if the player beat the opponent then it will
    //randomly drop an item which the player can gain
    public boolean battleCharacter(Character c2)
    {
        setRandomItemDrop(); //Will randomly choose if the opponent will drop an item
        ((Player)c2).changeFightLives(1); //to offset the fight life lost
        if(c2.battleCharacter(new Opponents(getName(), getHp(), getSp())))
        {
            if (item.checkItemFound()) {
                System.out.println("You have won the battle, take your item.");
                System.out.println("You have picked up a " + item.getItemName() + " from the " + getName());
            }
            else {
                System.out.println("You have won the battle no item drop");
            }
            return true;
        }
        else
        {
            return false;
        }
    }

    //Method randomly creates an item if chance of item drop met
    public void setRandomItemDrop()
    {
        double chanceItem = Math.random();
        assignRandomItem();
        if(chanceItem <= 0.5) {
            item.createItem(); //polymorphism
        }
        else
        {
            item.setCheckItemFound(false);
        }
    }

    //Method randomly assigns what type of item an item should be
    public void assignRandomItem()
    {
        Random r = new Random();
        int randInt = r.nextInt(3);

        if(randInt == 0)
        {
            item = new Armoury();
        }
        else if(randInt == 1)
        {
            item = new Potion();
        }
        else
        {
            item = new Skill();
        }
    }

    public void assignItemSkill()
    {
        item = new Skill();
    }

    //Method displays additional details about the item in class Opponents
    public void getStats()
    {
        super.getStats();
        setRandomItemDrop();
        if(item.checkItemFound())
        {
            System.out.println("Item: " + item.getItemName());
        }
        else
        {
            System.out.println("Item: Hidden");
        }
    }
}
