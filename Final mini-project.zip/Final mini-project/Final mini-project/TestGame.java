import java.util.Scanner;

public class TestGame {
    public static void main(String[] args) {
        Rounds round = new Rounds(10, 0);
        final int[] PLAYER_HP = new int[]{50, 60, 70, 80, 90, 100, 110, 120, 130, 140};
        final int[] PLAYER_SP = new int[]{50, 55, 60, 65, 70, 75, 80, 85, 90, 95};
        final int[] WARRIOR_HP = new int[]{75, 180, 270, 370, 475, 585, 705, 835, 980};
        final int[] WARRIOR_SP = new int[]{30, 70, 115, 170, 230, 295, 370, 455, 550, 670};
        final int[] Assassin_HP = new int[]{55, 120, 190, 270, 355, 445, 555, 665, 775, 885};
        final int[] Assassin_SP = new int[]{70, 150, 235, 330, 430, 535, 645, 760, 885, 1000};
        final int[] magicianXP = new int[]{30, 30, 50, 50, 70, 70, 90, 90, 110, 130};
        final int fightLives = 4;

        print("*******************");
        print("Gladiator Roulette");
        print("*******************");
        print("");
        print("Enter CHALLENGER to the arena. \nHere you will test your mettle against the mightiest champions this land has to offer." +
                "\nBattle your way through your foes and gain your seat as the next King of Valor.");
        print("\n");
        String playerName = inputString("State your name Challenger: ");

        Character [] fighters = new Character[2]; //index 0 is the player and index 1 is the opponent
        fighters[0] = createPlayer(playerName, PLAYER_HP[round.getRoundsSoFar()], PLAYER_SP[round.getRoundsSoFar()], fightLives, false);

        while (round.getRoundsSoFar() < round.getNumber_of_rounds())
        {
            if(round.getRoundsSoFar() != 0)
            {
                updatePlayer(fighters[0], PLAYER_HP[round.getRoundsSoFar()], PLAYER_SP[round.getRoundsSoFar()], ((Player)fighters[0]).getSkill()); //Player keeps stat changes from the previous round as well
            }
            fighters[1] = createOpponents(WARRIOR_HP, WARRIOR_SP, Assassin_HP, Assassin_SP, magicianXP, round.getRoundsSoFar()); //New opponent randomly created each round
            roundOptions(fighters, round);

            round.incrementRoundsSoFar();
        }

        print("\n");
        print("************END*****************END**************END*********");
        print("You have proven yourself worthy");
        print("Exit Arena");
        print("All hail the new King of Valor");
        print("************END*****************END**************END*********");
        System.exit(0);
    }

    //Method displays the options of which the player can choose from and displays stats of player and opponent at the
    //beginning of every round
    public static void roundOptions(Character [] fighters, Rounds round) {
        print("************************************************************");
        print("Round number: " + (round.getRoundsSoFar() + 1));
        print("");
        fighters[0].getStats(); //Player stats
        print("");
        print("Champion");
        print("------------");
        fighters[1].getStats(); //Opponent stats
        print("");

        boolean validInput = false;
        String choice = "";

        while (!validInput) {
            print("Make a decision:");
            print("Enter 'f' to FIGHT the champion");
            print("Enter 'm' to MINE for weapons and buffs");
            if (round.getRoundsSoFar() != 0) {
                print("Enter 'b' to SPEND your xp");
            }
            print("Enter 'c' to FLEE");
            choice = inputString("");
            validInput = checkValidInput(choice);

        }

        if (choice.equals("f")) {
            fight(fighters);
        } else if (choice.equals("m")) {
            mine(fighters, round);
            secondInput(fighters);
        } else if (choice.equals("b")) {
            spendXP(fighters);
            secondInput(fighters);
        } else {
            print("NO ESCAPING");
            print("Deserters deserve death");
            print("GAME OVER!!!");
            System.exit(0);
        }
    }

    //Method that displays the options but this time doesn't allow the player to mine and spendXP again
    public static void secondInput(Character[] fighters) {
        fighters[0].getStats();
        print("");
        print("Make a decision:");
        print("Enter 'f' to FIGHT the champion");
        print("Enter 'c' to FLEE");
        String choice = inputString("");

        if (choice.equals("f")) {
            fight(fighters);
        } else if (choice.equals("c")) {
            print("NO ESCAPING");
            print("Deserters deserve death");
            print("GAME OVER!!!");
            System.exit(0);
        } else {
            print("No second chances");
            System.exit(0);
        }
    }

    //Method for player to spend their xp to boost their stats
    public static void spendXP(Character [] fighters)
    {
        String choice = "";
        int xpSpend = 0;
        boolean validInput = false;
        while(!validInput){
            choice = inputString("Enter number 'x' for stat upgrade: " +
                    "\n1.Boost ATK \n2.Boost DEF \n3.Boost stamina(1 Fight Life for 25XP)");
            xpSpend = inputInt("Enter amount of xp to use: ");
            validInput = checkValidXpInput(choice, xpSpend, fighters[0]);
        }

        ((Player)fighters[0]).changeXP(-xpSpend);

        if(choice.equals("1")) //Boost attack
        {
            fighters[0].changeSp(xpSpend);
        }
        else if(choice.equals("2")) //Boost defence
        {
            fighters[0].changeHp(xpSpend);
        }
        else //Boost fight lives
        {
            ((Player)fighters[0]).changeFightLives((xpSpend/25));
        }

    }

    //Method returns random item if chance condition met and assigns items stats to the player
    public static void mine(Character [] fighters, Rounds round)
    {
        double chance = Math.random();
        ItemPool item;

        if(chance<0.1)
        {
            item = new Armoury();
        }
        else if(chance>= 0.1 & chance<0.9)
        {
            item = new Skill();
        }
        else
        {
            item = new Potion();
        }
        item.createItem(); //polymorphism

        if(!item.checkItemFound())
        {
            print("You lack a scavenger's eye.");
            print("You have not found anything\n");
            return;
        }
        else
        {
            item.getItemStats();
            if(item instanceof Armoury)
            {
                fighters[0].changeHp(((Armoury) item).getHp());
                fighters[0].changeSp(((Armoury) item).getSp());
            }
            else if(item instanceof Potion)
            {
                fighters[0].changeHp(((Potion) item).getHp());
                ((Player)fighters[0]).changeFightLives(((Potion) item).getFight_lives());
            }
            else
            {
                fighters[0].changeSp(((Skill) item).getSp());
                ((Player)fighters[0]).changeXP(((Skill) item).getXp());
                ((Player)fighters[0]).setSkill(true);
            }
            int bonus = item.miniGame(); //polymorphism -if a miniGame condition is met then the following will be executed
            if(bonus == -1) {
                round.incrementRoundsSoFar();
                ((Player)fighters[0]).setSkill(true);
            }
            else
            {
                fighters[0].changeHp(bonus);
                ((Player) fighters[0]).changeFightLives(bonus / 10);
            }
            ((Player)fighters[0]).changeXP(30); // gains xp if an item was mined
        }
    }

    //Method battles the characters together, with series of method options if player wins or loses
    public static void fight(Character [] fighters) {
        if(((Player) fighters[0]).getFightLives() != 0)
        {
            boolean outcome = fighters[1].battleCharacter(fighters[0]); //polymorphism
            fighters[0].battleCharacter(fighters[1]); //polymorphism
            if(!outcome) //player loses
            {
                if(((Player)fighters[0]).getDiedOnce() == 0) //player only lost once
                {
                    boolean quit = ((Player) fighters[0]).secondChance();
                    if(quit)
                    {
                        ((Player) fighters[0]).changeDiedOnce(1); //so cannot do secondChance method again if die again
                    }
                    else
                    {
                        print("You Lost");
                        System.exit(0);
                    }
                }
                else
                {
                    print("You Lost");
                    System.exit(0);
                }
            }
            else
            {
                int choice = inputInt("\nWant to summon champion: \n(1) for Yes \n(2) for No");
                if(choice == 1)
                {
                    ((Player) fighters[0]).summon(fighters[0], fighters[1]);
                    if (((Player) fighters[0]).getSummon())
                    {
                        System.out.println("Summoning succeeded");
                    }
                    else
                    {
                        System.out.println("Summoning failed");
                    }
                }
            }
        }
        else
        {
            print("FAIL");
            System.exit(0);
        }
    }


    //Methods check if player entered valid options
    public static boolean checkValidInput(String choice) {
        if (choice.equals("f") || choice.equals("m") || choice.equals("c") || choice.equals("b")) return true;
        else {
            print("No time for mistakes, consider this a warning " + "\nTRY AGAIN!!!\n");
            return false;
        }
    }
    public static boolean checkValidXpInput(String choice, int xp, Character fighter){
        if(choice.equals("1") || choice.equals("2") || choice.equals("3") && (xp >=0 && xp <= ((Player)fighter).getXP()))
        {
            if(choice.equals("3") && !(xp%25 ==0))
            {
                print("Don't want to make a mistake now");
                return false;
            }
            return true;
        }
        else {
            print("Don't want to make a mistake now");
            return false;
        }
    }

    //Methods to create and update player
    public static Player createPlayer(String name, int hp, int sp, int fl, boolean s) {
        Player p = new Player(name, hp, sp, fl, s);
        return p;
    }
    public static void updatePlayer(Character player, int hp, int sp, boolean s)
    {
        player.changeHp(hp);
        player.changeSp(sp);
        ((Player)player).setSkill(s);

        return;
    }

    //Method to create a new opponent randomly
    public static Opponents createOpponents(int[] whp, int[] wsp, int[] ahp, int[] asp,  int[] xp, int index)
    {
        Opponents opponent;
        double randInt = Math.random();
        if(randInt<0.35)
        {
            opponent = new Opponents("Assassin", ahp[index], asp[index]);
        }
        else if(randInt>=0.35 && randInt<0.7)
        {
            opponent = new Opponents("Warrior", whp[index], wsp[index]);
        }
        else
        {
            opponent = new Magician("Magician", ahp[index], wsp[index], xp[index]);
        }

        return opponent;
    }

    //Prints a String to screen and gets a String from keyboard
    public static String inputString(String message)
    {
        Scanner scanner = new Scanner(System.in);
        String answer;

        System.out.println(message);
        answer = scanner.nextLine();
        return answer;
    }

    //Prints a String to screen and gets an integer from keyboard
    public static int inputInt(String message)
    {
        String answer = inputString(message);
        return Integer.parseInt(answer);
    }

    //General method that prints to screen a String
    public static void print(String message)
    {
        System.out.println(message);
        return;
    }
}
