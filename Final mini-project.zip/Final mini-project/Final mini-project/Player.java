import java.util.Random;
import java.util.Scanner;

public class Player extends Character
{
    private int fight_lives; //How many fights can the player handle
    private int xp; //Experience points boost can be used to boost att
    private boolean skill;
    private boolean summon;
    private int diedOnce;

    public Player(String name, int hp, int sp, int fight_lives, boolean skill)
    {
        super(name, hp, sp);
        this.fight_lives = fight_lives;
        xp = 0;
        this.skill = skill;
        diedOnce = 0;
    }

    //Setter and getter methods to set, change and return fight_lives and xp
    public void setSkill(boolean b){skill = b;}
    public void changeXP(int newXP){xp += newXP;}
    public void changeFightLives(int newFL){fight_lives += newFL;}
    public void changeDiedOnce(int n){diedOnce += n;}
    public int getFightLives(){return fight_lives;}
    public int getXP(){return xp;}
    public boolean getSkill(){return skill;}
    public boolean getSummon(){return summon;}
    public int getDiedOnce(){return diedOnce;}

    public boolean battleCharacter(Character c)
    {
        changeFightLives(-1); //Decreases a fight life with each fight
        if((((Opponents)c).getItem() instanceof Skill)) //if item drop from opponent is a skill
        {
            setSkill(true);
        }
        else
        {
            setSkill(false);
        }

        if(super.battleCharacter(c))
        {
            changeXP(20); //If player wins a fight then gains xp points
            return true;
        }
        else
        {
            return false;
        }
    }

    //Method where if the player beats the opponent then they have chance to summon the opponent and gain some of their
    //stats
    public void summon(Character c, Character c2)
    {
        double chance = Math.random();
        if(chance<=0.3)
        {
            summon = true;
            c.changeHp(c2.getHp()/20); //Gain stats from opponent
            c.changeSp(c2.getSp()/20);
        }
        else
        {
            summon = false;
        }
    }

    //Method is called if the player died once, if chance condition met and the player chooses a correct option then
    //they can continue with the game
    public boolean secondChance()
    {
        double chance = Math.random();
        Random r = new Random();
        int randGlass = r.nextInt(3) + 1; // randomly selects an option
        if((chance<=0.7))
        {
            System.out.println("\nPick a glass 1, 2 or 3");
            System.out.println("If you drink from the right one, you can save your unworthy soul!");
            Scanner scanner = new Scanner(System.in);
            int answer = Integer.parseInt(scanner.nextLine());
            if(randGlass == answer)// if player answer and the randomly selected answer are the same
            {
                System.out.println("\nYou have earned a second chance");
                changeHp(-50);
                changeSp(-50);
                changeXP(30);
                return true;
            }
            else
            {
                System.out.println("Your luck is that of a fools");
                return false;
            }
        }
        else
        {
            return false;
        }
    }

    //The method displays additional details of fight lives remaining and xp for players
    public void getStats()
    {
        super.getStats();
        System.out.println("Fight lives remaining: " + getFightLives());
        System.out.println("XP: " + getXP());
        if (getSkill())
        {
            setSkill(true);
            System.out.println("Skill: Equipped");
        }
    }
}
