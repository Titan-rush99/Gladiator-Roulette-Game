import java.util.Scanner;

public class Potion extends ItemPool
{
    private int hp;
    private int fight_lives;

    public Potion()
    {
        super();
        hp = 0;
        fight_lives = 0;
    }

    //setter and getter methods to edit or return the states in Potion
    public void setHp(int hp){this.hp = hp;}
    public void setFight_lives(int fl){fight_lives = fl;}
    public int getHp(){return hp;}
    public int getFight_lives(){return fight_lives;}

    //Overrides the method in ItemPool, the method, based on the rarity of item created by createItem method in the
    //superclass, will call the assignStats method
    public void createItem()
    {
        int chance = getRandomInt(100) +1;
        super.createItem();
        if(getRarity().equals("Common"))
        {
            assignStats(chance, 10);
        }
        else if(getRarity().equals("Uncommon"))
        {
            setCheckItemFound(false);
        }
        else if(getRarity().equals("Rare"))
        {
            assignStats(chance, 30);
        }
    }

    //Method use chance to select which potion to bestow and assigns it a power
    public void assignStats(int chance, int power)
    {
        if(chance<=40)
        {
            setName("Health potion");
            setHp(power);
        }
        else
        {
            setName("Stamina potion");
            setFight_lives(power/10);
        }
    }

    //Method overrides miniGame method in SuperClass ItemPool, player selects two options and if they are not the same
    //selected options and the chance condition is met then a boost is applied to the potion item
    public int miniGame()
    {
        double chance = Math.random();
        System.out.println("\nYou have found a hidden rune!");
        System.out.println("Select and match two of the following: to win a special bonus:");
        Scanner scanner = new Scanner(System.in);
        System.out.println("A\tB\tC");
        System.out.println("A\tB\tC\n");
        System.out.println("Choice 1:");
        String answer = scanner.nextLine();
        System.out.println("Choice 2:");
        String answer2 = scanner.nextLine();

        if((chance<0.6))
        {
            if(!answer.equals(answer2))// if the player's two chosen options are not the same
            {
                System.out.println("\nYou lucky savage!");
                System.out.println("You have conquered the rune.");
                System.out.println("Obtained special bonus.");
                return 20;
            }
            else
            {
                return super.miniGame(); // return 0
            }
        }
        return super.miniGame();
    }

    public void getItemStats()
    {
        if(checkItemFound())
        {
            if(getItemName().equals("Health potion"))
            {
                System.out.println("You have obtained a potion.");
                System.out.println("Item: " + getRarity() + " " + getItemName());
                System.out.println("Item hp: " + getHp());
                System.out.println("You have drank the potion.\n");
            }
            else
            {
                System.out.println("You have obtained a potion.");
                System.out.println("Item: " + getRarity() +  " " + getItemName());
                System.out.println("Item increase fight lives: " + getFight_lives());
                System.out.println("You have drank the potion.\n");
            }
        }
        else
        {
            System.out.println("You have not found anything.\n");
        }
    }
}